--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5 (Debian 14.5-1.pgdg110+1)
-- Dumped by pg_dump version 14.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tgs;
--
-- Name: tgs; Type: DATABASE; Schema: -; Owner: tgs
--

CREATE DATABASE tgs WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE tgs OWNER TO tgs;

\connect tgs

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chat; Type: TABLE; Schema: public; Owner: tgs
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    "bindAt" timestamp without time zone NOT NULL,
    "userUsername" character varying
);


ALTER TABLE public.chat OWNER TO tgs;

--
-- Name: message; Type: TABLE; Schema: public; Owner: tgs
--

CREATE TABLE public.message (
    id integer NOT NULL,
    content text NOT NULL,
    "sentAt" timestamp without time zone NOT NULL,
    "receiverUsername" character varying
);


ALTER TABLE public.message OWNER TO tgs;

--
-- Name: message_id_seq; Type: SEQUENCE; Schema: public; Owner: tgs
--

CREATE SEQUENCE public.message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.message_id_seq OWNER TO tgs;

--
-- Name: message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tgs
--

ALTER SEQUENCE public.message_id_seq OWNED BY public.message.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: tgs
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


ALTER TABLE public.migrations OWNER TO tgs;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: tgs
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO tgs;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: tgs
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: tgs
--

CREATE TABLE public."user" (
    username character varying NOT NULL,
    name character varying,
    email character varying
);


ALTER TABLE public."user" OWNER TO tgs;

--
-- Name: message id; Type: DEFAULT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.message ALTER COLUMN id SET DEFAULT nextval('public.message_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: tgs
--

COPY public.chat (id, "bindAt", "userUsername") FROM stdin;
\.
COPY public.chat (id, "bindAt", "userUsername") FROM '$$PATH$$/3336.dat';

--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: tgs
--

COPY public.message (id, content, "sentAt", "receiverUsername") FROM stdin;
\.
COPY public.message (id, content, "sentAt", "receiverUsername") FROM '$$PATH$$/3335.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: tgs
--

COPY public.migrations (id, "timestamp", name) FROM stdin;
\.
COPY public.migrations (id, "timestamp", name) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: tgs
--

COPY public."user" (username, name, email) FROM stdin;
\.
COPY public."user" (username, name, email) FROM '$$PATH$$/3333.dat';

--
-- Name: message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tgs
--

SELECT pg_catalog.setval('public.message_id_seq', 1, false);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tgs
--

SELECT pg_catalog.setval('public.migrations_id_seq', 1, true);


--
-- Name: user PK_78a916df40e02a9deb1c4b75edb; Type: CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT "PK_78a916df40e02a9deb1c4b75edb" PRIMARY KEY (username);


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: chat PK_9d0b2ba74336710fd31154738a5; Type: CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT "PK_9d0b2ba74336710fd31154738a5" PRIMARY KEY (id);


--
-- Name: message PK_ba01f0a3e0123651915008bc578; Type: CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT "PK_ba01f0a3e0123651915008bc578" PRIMARY KEY (id);


--
-- Name: chat FK_108f0d6677e283315af8f30151b; Type: FK CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT "FK_108f0d6677e283315af8f30151b" FOREIGN KEY ("userUsername") REFERENCES public."user"(username);


--
-- Name: message FK_838b22ffd982823818680c50064; Type: FK CONSTRAINT; Schema: public; Owner: tgs
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT "FK_838b22ffd982823818680c50064" FOREIGN KEY ("receiverUsername") REFERENCES public."user"(username);


--
-- PostgreSQL database dump complete
--

